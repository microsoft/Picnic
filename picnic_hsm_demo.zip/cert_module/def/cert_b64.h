/*! @file cert_b64.h
 *  @brief Cert module Base64 helper
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */

#ifndef __B64_H__
#define __B64_H__

void decodeBase64(char *, unsigned int, char *, unsigned int *);

void encodeToBase64(unsigned char *, unsigned int, char *, unsigned int *);

#endif
