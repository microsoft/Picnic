/*! @file picnic.h
 *  @brief Picnic HSM module header file.
 *  Include this header to call the Picnic module from another module.
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef __PICNIC_H_INCLUDED__
#define __PICNIC_H_INCLUDED__

#include <os_mdl.h>
#include <os_file.h>

// module id and module name (change the id if the ID is already in use by another custom module.)
#define PICNIC_MDL_ID      0x105    // Can be anthing above 0x100
#define PICNIC_MDL_NAME    "PICNIC" // limited to 8 chars

#ifdef CS2_SDK  // CS2_SDK defined when using the simulator
#define PICNIC_MDL_NAMEX   "Picnic Signature Module SDK"
#else
#ifdef DEBUG
#define PICNIC_MDL_NAMEX   "Picnic Signature Module DEBUG"
#else
#define PICNIC_MDL_NAMEX   "Picnic Signature Module"
#endif
#endif

#define PICNIC_MDL_VERSION 0x01010001 // = 1.1.0.1


// public interface
typedef struct
{
    // required HSM fields
    void *p_data;
    int(*p_start)(T_OS_MDL_HDL, OS_FILE_HANDLE, void*);
    int(*p_stop)(void);
    int(*p_pre_replace)(void);
    int(*p_pre_delete)(void);
    void *dumy;
    const void *p_module_info;

    // public interface
    int(*p_pub_sign)(unsigned int l_sec, unsigned char *p_sec, unsigned int l_m, unsigned char *p_m, unsigned int *p_l_sign, unsigned char **pp_sign);
    int(*p_pub_verify)(unsigned int l_pub, unsigned char *p_pub, unsigned int l_m, unsigned char *p_m, unsigned int l_sign, unsigned char *p_sign);
    int(*p_pub_keygen)(unsigned int params, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub);
    int(*p_pub_keychk)(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub);
    int(*p_pub_sign_decode)(unsigned int l_sign, unsigned char* p_sign, unsigned int *p_l_s, unsigned char **pp_s);
    int(*p_pub_sign_encode)(unsigned int l_s, unsigned char *p_s, unsigned int *p_l_sign, unsigned char *p_sign);
    int(*p_pub_key_decode)(unsigned int l_key, unsigned char *p_key, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub, unsigned int *p_l_oid, unsigned char **pp_oid);
    int(*p_pub_key_encode)(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub, unsigned int l_oid, unsigned char *p_oid, unsigned int *p_l_key, unsigned char *p_key);
}
T_PICNIC_TABLE_PUB;


// function prototypes when this header is included in the picnic module
#ifdef _PICNIC_C_INT_

//  required HSM adminitration functions
int picnic_start(T_OS_MDL_HDL, OS_FILE_HANDLE, void *);
int picnic_stop(void);
int picnic_pre_replace(void);
int picnic_pre_delete(void);

//  public  functions
int picnic_sign(unsigned int l_sec, unsigned char *p_sec, unsigned int l_m, unsigned char *p_m, unsigned int *p_l_sign, unsigned char **pp_sign);
int picnic_verify(unsigned int l_pub, unsigned char *p_pub, unsigned int l_m, unsigned char *p_m, unsigned int l_sign, unsigned char *p_sign);
int picnic_keygen(unsigned int params, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub);
int picnic_keychk(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub);
int picnic_sign_decode(unsigned int l_sign, unsigned char *p_sign, unsigned int *p_l_s, unsigned char **pp_s);
int picnic_sign_encode(unsigned int l_s, unsigned char *p_s, unsigned int *p_l_sign, unsigned char *p_sign);
int picnic_key_decode(unsigned int l_key, unsigned char *p_key, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub, unsigned int *p_l_oid, unsigned char **pp_oid);
int picnic_key_encode(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub, unsigned int l_oid, unsigned char *p_oid, unsigned int *p_l_key, unsigned char *p_key);


// function prototypes when this header is included by other modules
#else

extern  MDL_GLOBAL T_OS_MDL_HDL P_PICNIC;

#define _P_PICNIC  ((T_PICNIC_TABLE_PUB *)P_PICNIC)

// required hsm functions
#define picnic_start        _P_PICNIC->p_start
#define picnic_stop         _P_PICNIC->p_stop
#define picnic_pre_replace  _P_PICNIC->p_pre_replace
#define picnic_pre_delete   _P_PICNIC->p_pre_delete

// public functions
#define picnic_pub_sign        _P_PICNIC->p_pub_sign
#define picnic_pub_verify      _P_PICNIC->p_pub_verify
#define picnic_pub_keygen      _P_PICNIC->p_pub_keygen
#define picnic_pub_keychk      _P_PICNIC->p_pub_keychk
#define picnic_pub_sign_decode _P_PICNIC->p_pub_sign_decode
#define picnic_pub_sign_encode _P_PICNIC->p_pub_sign_encode
#define picnic_pub_key_decode  _P_PICNIC->p_pub_key_decode
#define picnic_pub_key_encode  _P_PICNIC->p_pub_key_encode


#endif // _PICNIC_C_INT_


// error codes.  All begin with 0xB105

#define E_PICNIC                          0xB105          // CryptoServer module PICNIC
#define E_PICNIC_PERMISSION_DENIED        0xB1050001      // permission denied
#define E_PICNIC_PARAM                    0xB1050002      // invalid parameter
#define E_PICNIC_PARAM_LEN                0xB1050003      // invalid parameter length
#define E_PICNIC_MALLOC                   0xB1050004      // memory allocation failed
#define E_PICNIC_MODE                     0xB1050005      // invalid mode
#define E_PICNIC_ITEM_NOT_FOUND           0xB1050006      // item not found
#define E_PICNIC_MODULE_DEP               0xB1050007      // unresolved module dependency
#define E_PICNIC_FILE_IO                  0xB1050008      // file I/O error
#define E_PICNIC_KGEN_FAILED              0xB1050009      // keygen failed
#define E_PICNIC_KSERIALIZE_FAILED        0xB105000A      // key serialization failed
#define E_PICNIC_KDESERIALIZE_FAILED      0xB105000B      // key de-serialization failed
#define E_PICNIC_SIGN_FAILED              0xB105000C      // sign failed
#define E_PICNIC_VERIFY_FAILED            0xB105000D      // verify failed


#endif // __PICNIC_H_INCLUDED__
