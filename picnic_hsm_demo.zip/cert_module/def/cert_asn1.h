/*! @file cert_asn1.h
 *  @brief Cert module ASN1 helper functions
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef __ASN1_H__
#define __ASN1_H__


#include <asn1.h>
#include <os_str.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <util.h>


#define mallocSD(size) os_mem_new(size, OS_MEM_TYPE_SD) 


static const unsigned char PATHS_SERIAL[3] = { 1, 2, 0 };
static const unsigned char PATHS_EXPIRY[4] = { 1, 5, 1, 0 };
static const unsigned char PATHS_EXTENSIONS[4] = { 1, 8, 1, 0 };

typedef struct oid_t { const char *name; char *oid; } oid_t;

typedef struct asn1_table {
    ASN1_ITEM * table;
    unsigned int length;
} asn1_table;

static const oid_t oidTable[] = {
    { "C",  "2.5.4.6" },
    { "L",  "2.5.4.7" } ,
    { "CN", "2.5.4.3" },
    { "ST", "2.5.4.8" },
    { "O",  "2.5.4.10" } ,
    { "OU", "2.5.4.11" } ,
    { "E",  "1.2.840.113549.1.9.1" } ,
    { NULL, "\0" }
};

void printHex(const char* s, unsigned char * data, unsigned int len);

void freeTable(ASN1_ITEM * table);

int asn1_memmove(void * dest, void * source, unsigned int length);

int asn1_fix_item_lengths(ASN1_ITEM * parent);

int asn1_get_child_count(ASN1_ITEM *);

int asn1_get_item_total_len(ASN1_ITEM *);

int asn1_encode_item(ASN1_ITEM *, unsigned char **, size_t *);

int asn1_decode_pem(char * beginTag, char * endTag, unsigned char * data,  asn1_table * tableOut);

int asn1_delete_item(asn1_table* table, ASN1_ITEM * toDelete);

int asn1_copyItem(ASN1_ITEM * itemToCopy, ASN1_ITEM** copyTable, size_t * copyTableLen, bool copyData);

int asn1_clone_table(ASN1_ITEM * item, ASN1_ITEM * clone);

ASN1_ITEM * asn1_create_item(unsigned int tag, unsigned char * initialValue, unsigned int * initialValueLen);

void asn1_set_item(ASN1_ITEM * item, unsigned int tag, unsigned char * data, unsigned int dataLen, unsigned int childCount);

void asn1_set_integer(ASN1_ITEM * item, unsigned char * data, unsigned int * dataLen);

int asn1_set_bitstring(ASN1_ITEM * bitstring, unsigned char * content, size_t len);

int asn1_set_bitstring_from_asn1(ASN1_ITEM * bitstring, ASN1_ITEM * content);

void asn1_lookup_property_oid(char * name, const char ** value);

void asn1_time_to_UTCTime(TIME_STR * time, unsigned char * outBuff);

int asn1_find_by_path(asn1_table * table, const unsigned char * path, asn1_table * output);

int asn1_get_sub_table_by_path(asn1_table * table, const unsigned char * path, asn1_table * subTable);

void asn1_oid_str_to_bytes(char * oid, unsigned char ** oidBytes, size_t * oidBytesLen);

void asn1_print_table(asn1_table * tableSize);

void asn1_free_table(asn1_table table);

void asn1_copy_data_buffer(asn1_table table);

#endif // __ASN1_H__
