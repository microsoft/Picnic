/*! @file cert_ext.h
 *  @brief Implementation of the Cert module external API
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef _CERT_EXT_H_
#define _CERT_EXT_H_

#include <db.h>

extern MDL_GLOBAL DB *P_db;

extern int cert_ext_generateCAKeyPair(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);

extern int cert_ext_generate_cert(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);

extern int cert_ext_verifyCertSignature(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);

#endif
