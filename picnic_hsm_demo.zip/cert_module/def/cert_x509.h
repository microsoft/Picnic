/*! @file cert_x509.h
 *  @brief Cert module X509 helper functions
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef __X509_H__
#define __X509_H__


#include <asn1.h>
#include <util.h>
#include <os_str.h>
#include <hash.h>
#include <stdint.h>
#include "cert_asn1.h"


#define TABLEWORKSPACESIZE 200
static ASN1_ITEM tableWorkspace[TABLEWORKSPACESIZE];


int x509_new_empty_certificate(asn1_table * cert);

int x509_set_serial(ASN1_ITEM * table, unsigned char * serial, size_t * serialLen);

int x509_new_name(char * properties, asn1_table * output);

int x509_new_dn_property(char * prop, char * value, ASN1_ITEM * output);

int x509_set_alg_id(char * oidStr);

int x509_create_cert(
    int certType,
    asn1_table * cert,
    unsigned char * serial,
    size_t serialLen,
    char * algorithmOid,
    char * issuerDN,
    char * subjectDN,
    size_t daysUntilExpired,
    char * publicKeyOid,
    unsigned char * publicKeyBytes0,
    size_t publicKeyLen0);

int x509_set_expiry(asn1_table table, size_t days);

int x509_new_public_key(ASN1_ITEM ** publicKeyItem, char * publicKeyOid, bool params, unsigned char * keyBytes0, size_t kbLen0, unsigned char * keyBytes1, size_t kbLen1);

int x509_set_public_key(ASN1_ITEM * itemToReplace, ASN1_ITEM * pkTable);

int x509_new_subject_key_identifier2(asn1_table publicKeyItem, asn1_table * output);

int x509_set_subject_key_identifier(ASN1_ITEM * extensions, ASN1_ITEM * skiTable);

int x509_new_basic_constraints2(unsigned int certType, asn1_table * output);

int x509_set_basic_constraints(ASN1_ITEM * extensions, ASN1_ITEM * bcTable);

int x509_set_signature_alg(asn1_table cert, char * oidStr);

int x509_set_signature(asn1_table cert, unsigned char * signature, unsigned int signatureLen);

#endif // __X509_H__
