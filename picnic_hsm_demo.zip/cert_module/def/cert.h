/*! @file cert.h
 *  @brief Cert HSM module header file.
 *  Include this header to call the Cert module from another module.
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef __CERT_H__
  #define __CERT_H__

#include <os_mdl.h>
#include <os_file.h>


// module id and module name (change the id if the ID is already in use by another custom module.)
#define CERT_MDL_ID          0x102  // Can be anthing above 0x100
#define CERT_MDL_NAME        "CERT" // limited to 8 chars
#define CERT_MDL_NAMEX       "Cert Module"
#define CERT_MDL_VERSION     0x01010001 // = 1.1.0.1
#define OID_PICNIC           "1.3.6.1.4.1.311.99.1.1"


// public interface (struct required by cert_global.c)
typedef struct
{
    // required HSM fields
    void   *p_data;
    int    (*p_start)(T_OS_MDL_HDL, OS_FILE_HANDLE, void*);
    int    (*p_stop)(void);
    int    (*p_pre_replace)(void);
    int    (*p_pre_delete)(void);
    void   *dumy;
    const void *p_module_info;

    // public functions would go here if we had any.
}
T_CERT_TABLE_PUB;


//  required HSM adminitration functions
int  cert_start(T_OS_MDL_HDL,OS_FILE_HANDLE,void *);
int  cert_stop(void);
int  cert_pre_replace(void);
int  cert_pre_delete(void);


// error codes                                             All begin with 0xB102
#define E_CERT                          0xB102          // CryptoServer module CERT
#define E_CERT_PARAM                    0xB1020001      // invalid parameter
#define E_CERT_PARAM_LEN                0xB1020002      // invalid parameter length
#define E_CERT_MALLOC                   0xB1020003      // memory allocation failed
#define E_CERT_MODE                     0xB1020004      // invalid mode
#define E_CERT_ITEM_NOT_FOUND           0xB1020005      // item not found
#define E_CERT_FILE_IO                  0xB1020006      // file I/O error


#endif //__CERT_H__
