/*! @file cert_int.h
 *  @brief Internal Cert Module functions
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef __CERT_INT_H
#define __CERT_INT_H


int getCertSignature(
    unsigned int l_pk, unsigned char *p_pk, unsigned int l_sk, unsigned char *p_sk,
    unsigned char * message, unsigned int messageLen, unsigned char ** p_signature,
    unsigned int * p_l_signature);


int loadKeys(char * keyPairName, unsigned int * p_l_pk, unsigned char ** pp_pk,
     unsigned int * p_l_sk, unsigned char ** pp_sk);


int saveCAName(char * filename, char * properties);


int loadCAName(char * filename, char ** caName);


#endif
