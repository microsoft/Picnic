/*! @file cert_host.c
*  @brief Cert HSM module host file.
*  Include this header to call the Picnic module from another module.
*
*  The code is provided under the MIT license, see LICENSE for
*  more details.
*  SPDX-License-Identifier: MIT
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#ifdef WIN32
#include <conio.h>
#endif
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <load_store.h>
#include <csxapi.h>
#include <csa_cmds.h>

// Set your device here
#define DEVICE "3001@127.0.0.1"    // Simulator IP
//#define DEVICE "10.10.10.10"     // HSM IP

// module id of example module
#define PICNIC_MDL_ID             0x105
#define CERT_MDL_ID               0x102

// sub function codes of the example module
#define CERT_SFC_GENERATE_CERT      0
#define CERT_SFC_VERIFY_CERT        1
#define CERT_SFC_GENERATE_CA_KEY    2

// cert types
#define CERT_TYPE_CA_FROM_INPUT     1
#define CERT_TYPE_EE_FROM_CSR       2
#define CERT_TYPE_EE_FROM_INPUT     3

// console text colors
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

#define INPUT_BUFFER_LEN 32


typedef enum { caFromInput, eeFromInput, eeFromCSR } certType;


static void print_msg(unsigned char *p_msg, int len)
{
    static int msg_mode = 0;

    while (--len >= 0)
    {
        if (msg_mode == 0)
        {
            putchar('!');
            putchar(' ');
            msg_mode = 1;
        }

        if (*p_msg == '\n') msg_mode = 0;
        putchar(*p_msg++);
    }
}


void printHex(const char* s, unsigned char * data, size_t len)
{
    size_t i;
    printf("%s: ", s);
    for (i = 0; i < len; i++) {
        printf("%02X", data[i]);
    }
    printf("\n");
}


void propertyPromt(char * buffer, char * prompt, char * property, char * def) {
    // if the user types more than the buffer, the remainder goes to the next prompt

    char inputBuffer[INPUT_BUFFER_LEN];
    size_t inputLen = 0;

    memset(inputBuffer, 0, INPUT_BUFFER_LEN);

    printf("%s [%s]:", prompt, def);
    fgets(inputBuffer, INPUT_BUFFER_LEN, stdin);
    inputLen = strcspn(inputBuffer, "\r\n");

    if (inputLen == 0) {
        memcpy(inputBuffer, def, strlen(def) + 1);
    }

    sprintf(buffer, "%s/%s=%s", buffer, property, inputBuffer);

    return;
}


void promtForDN(char ** buffer, unsigned int * bufferLen, unsigned int * days) {

    char inputBuffer[INPUT_BUFFER_LEN];

    char * combinedInput = malloc(INPUT_BUFFER_LEN * 10);
    memset(combinedInput, 0, INPUT_BUFFER_LEN * 10);

    printf("Enter information for the Distinguished Name (DN)\n");
    printf("Hit [enter] to use the default value in brackets.\n");

    combinedInput[0] = 0;

    propertyPromt(combinedInput, "\nCountry Name(2 letter code)", "C", "US");

    propertyPromt(combinedInput, "\nState or Province Name(full name)", "ST", "WA");

    propertyPromt(combinedInput, "\nLocality Name(eg, city)", "L", "Redmond");

    propertyPromt(combinedInput, "\nOrganization Name(eg, company)", "O", "MyCompany");

    propertyPromt(combinedInput, "\nOrganizational Unit Name(eg, section)", "OU", "MyOrganization");

    propertyPromt(combinedInput, "\nCommon Name(e.g.server FQDN or YOUR name)", "CN", "PicnicCA");

    printf("\ndays until expired [365] : ");
    fgets(inputBuffer, 33, stdin);
    inputBuffer[strcspn(inputBuffer, "\r\n")] = 0;
    if (strlen(inputBuffer) == 0) {
        memcpy(inputBuffer, "365\0", 4);
    }

    *days = (unsigned int)strtol(inputBuffer, NULL, 10);
    *buffer = combinedInput;
    *bufferLen = (unsigned int)strlen(combinedInput) + 1;

    return;
}


int promtAndReadFile(const char * prompt, unsigned char ** buffer, unsigned int * len) {

    char path[256];
    FILE *fp = NULL;
    char * p;

    do {
        printf("\n%s", prompt);
        fgets(path, 256, stdin);
        path[strcspn(path, "\r\n")] = 0;

        if(path[0] == '"') {
            path[strcspn(path + 1, "\"") + 1] = 0;
            fp = fopen(&path[1], "r");
        } 
        else {
            fp = fopen(path, "r");
        }
        
        if (fp == NULL) {
            printf("\n%s not found.", path);
        }

    } while (fp == NULL);

    // get the length of the file
    fseek(fp, 0, SEEK_END);

    *len = (unsigned int)ftell(fp) + 1;

    // alloc mem for the command.  len+certdata
    *buffer = malloc(*len);

    // read the file into the command
    fseek(fp, 0, SEEK_SET);
    fread(*buffer, sizeof(char), *len, fp);
    fclose(fp);

    (*buffer)[*len - 1] = 0; //zero terminate

    return 0;

}


int picnic_demo_generateCert(int h_cs, void *p_sess_ctx, int certType)
{
    int             err = 0;

    unsigned char   *cmd;
    unsigned char   *p_cmd;

    unsigned int    l_cmd = 0;
    unsigned char   *p_answ = NULL;
    unsigned int	 p_l_answ = 0;

    unsigned char * csrBuffer = NULL;
    unsigned int csrBufferLen = 0;

    unsigned int days = 0;

    if (certType == eeFromInput || certType == caFromInput) {
        promtForDN(&csrBuffer, &csrBufferLen, &days);
    }
    else if (certType == eeFromCSR) {
        promtAndReadFile("CSR File Path: ", &csrBuffer, &csrBufferLen);
    }

    l_cmd = 2 + 2 + 2 + csrBufferLen;
    cmd = malloc(l_cmd * 2);
    p_cmd = cmd;

    store_int2(certType, p_cmd);
    p_cmd += 2;

    store_int2(days, p_cmd);
    p_cmd += 2;

    store_int2(csrBufferLen, p_cmd);
    p_cmd += 2;

    memcpy(p_cmd, csrBuffer, csrBufferLen);
    p_cmd += csrBufferLen;


    if ((err = cs_exec_command(h_cs, \
        p_sess_ctx, \
        CERT_MDL_ID, \
        CERT_SFC_GENERATE_CERT, \
        cmd, \
        l_cmd, \
        &p_answ, \
        &p_l_answ)) != 0)
        goto cleanup;

    char * fileName = NULL;

    switch (certType) {

    case caFromInput:
        fileName = "picnicCA.crt";
        break;
    case eeFromInput:
        fileName = "picnicEE.crt";
        break;
    case eeFromCSR:
        fileName = "picnicEEFromCSR.crt";
        break;

    default:
        printf("unknown cert type\n");
        return -1;
    }

    // write cert to file
    FILE *fp;
    fp = fopen(fileName, "w");
    if (fp == NULL)
        exit(-1);

    fwrite(p_answ, 1, p_l_answ, fp);
    fclose(fp);

    char * fullpath = malloc(256);
    _fullpath(fullpath, fileName, 256);

    system("cls");

    printf("cert generated: " ANSI_COLOR_YELLOW  "%s\n\n" ANSI_COLOR_RESET, fullpath);

cleanup:
    cs_free_answ(p_answ);

    return err;
}


int picnic_demo_verifyCert(int h_cs, void *p_sess_ctx)
{
    int             err = 0;
    unsigned char * cmd;
    unsigned int    l_cmd = 0;
    unsigned char * p_answ = NULL;
    unsigned int    p_l_answ = 0;
    unsigned char * fileBuffer = NULL;
    unsigned int    fileBufferLen = 0;

    promtAndReadFile("Cert File Path:", &fileBuffer, &fileBufferLen);

    l_cmd = 4 + fileBufferLen;
    cmd = malloc(l_cmd);
    store_int4(fileBufferLen, cmd);
    memcpy(cmd + 4, fileBuffer, fileBufferLen);

    // send the command
    if ((err = cs_exec_command(h_cs, \
        p_sess_ctx, \
        CERT_MDL_ID, \
        CERT_SFC_VERIFY_CERT, \
        cmd, \
        l_cmd, \
        &p_answ, \
        &p_l_answ)) != 0)
        goto cleanup;

    system("cls");
    printf("Verify Cert:" ANSI_COLOR_YELLOW " %s ", (int)*p_answ == 0 ? "true" : "false");
    printf(ANSI_COLOR_RESET "\n");

cleanup:
    cs_free_answ(p_answ);

    return err;
}


int picnic_demo_generate_ca_key(int h_cs, void *p_sess_ctx)
{
    int             err = 0;
    unsigned char   cmd[4] = { 0,0,0,0 };
    unsigned int    l_cmd = 4;
    unsigned char   *p_answ = NULL;
    unsigned int	p_l_answ = 0;

    printf("\nSelect security level:\n");
    printf(" 1] Picnic_L1_FS\n");
    printf(" 3] Picnic_L3_FS\n");
    printf(" 5] Picnic_L5_FS\n");


    char selection = 0;
    while (selection == 0) {
        selection = _getch();
        switch (selection)
        {
        case '1':
        case '3':
        case '5':
            cmd[3] = selection - '0';
            break;
        default:
            selection = 0;
            break;
        }
    }

    if ((err = cs_exec_command(h_cs, \
        p_sess_ctx, \
        CERT_MDL_ID, \
        CERT_SFC_GENERATE_CA_KEY, \
        cmd, \
        l_cmd, \
        &p_answ, \
        &p_l_answ)) != 0)
        goto cleanup;

    system("cls");
    printf("Picnic public key " ANSI_COLOR_YELLOW);
    printHex("", p_answ, p_l_answ);
    printf(ANSI_COLOR_RESET "\n");

    cs_free_answ(p_answ);

    return 0;

cleanup:

    cs_free_answ(p_answ);

    return err;
}


void showMenu() {

    // generate root picnic CA key 
    printf("1]  Generate root picnic CA key (replaces existing)\n\n");

    // generate self-signed picnic CA cert
    printf("2]  Generate self-signed pinic CA cert\n\n");

    // generate self-signed picnic CA cert
    printf("3]  Generate CA-signed pinic EE cert\n\n");

    // request end-entity cert from csr
    printf("4]  Request End-Entity cert from CSR\n\n");

    // request end-entity cert from csr
    printf("5]  Verify certificate signature\n\n");

    printf("X]  Exit\n");

}


void main(void)
{
    int   err = 0;
    int   h_cs = -1;
    void  *p_sess_ctx = NULL;


    // open connection to CryptoServer
    // try twice since simulator can take a bit to spin up.
    if ((err = cs_open_connection(DEVICE, 5000, 180000, &h_cs)) != 0)
    {
        printf("cs_open_connection returned: 0x%08x\n", err);

        if ((err = cs_open_connection(DEVICE, 5000, 180000, &h_cs)) != 0)
        {
            printf("cs_open_connection returned: 0x%08x\n", err);
            goto cleanup;
        }
    }

    if ((err = cs_set_msg_handler(h_cs, print_msg)) != 0)
    {
        printf("cs_set_msg_handler returned: 0x%08x\n", err);
        goto cleanup;
    }

    while (1) {
        showMenu();
        char selection = _getch();

        switch (selection) {
        case '0':
            break;
        case '1':
            picnic_demo_generate_ca_key(h_cs, NULL);
            break;
        case '2':
            picnic_demo_generateCert(h_cs, NULL, caFromInput);
            break;
        case '3':
            picnic_demo_generateCert(h_cs, NULL, eeFromInput);
            break;
        case '4':
            picnic_demo_generateCert(h_cs, NULL, eeFromCSR);
            break;
        case '5':
            picnic_demo_verifyCert(h_cs, NULL);
            break;
        case 'x':
        case 'X':
            goto exit;
            break;
        default:
            break;
        }
    }

exit:

cleanup:
    if (h_cs >= 0)
    {
#ifdef USE_SM
        if (p_sess_ctx != NULL)
            cs_logoff(h_cs, p_sess_ctx);
#endif
        cs_close_connection(h_cs);
    }

    if (err != 0)
    {
        puts(cs_get_error_msg(err));
    }

    }
