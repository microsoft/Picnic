/*! @file cert_x509.c
 *  @brief Cert module X509 helper functions
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#include "cert_x509.h"
#include <os_log.h>


int x509_new_empty_certificate(asn1_table * cert) {

    //Certificate
    //    Version Number
    //    Serial Number
    //      Signature Algorithm ID
    //    Issuer Name
    //    Validity period
    //      Not Before
    //      Not After
    //    Subject name
    //    Subject Public Key Info
    //      Public Key Algorithm
    //      Subject Public Key
    //    Issuer Unique Identifier(optional)
    //    Subject Unique Identifier(optional)
    //    Extensions(optional)
    //    ...
    //Certificate Signature Algorithm
    //Certificate Signature

    unsigned int i = 0;
    ASN1_ITEM * t = tableWorkspace;
    unsigned char * two = mallocSD(1);
    *two = 2;

    // Root
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 3);

    // Certificate
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 8);

    //    Version Number (v3 default)
    asn1_set_item(&t[i++], ASN_SE(0), NULL, 0, 1); // A0
    asn1_set_item(&t[i++], ASN_INTEGER, two, 1, 0);

    //    Serial Number
    asn1_set_item(&t[i++], ASN_INTEGER, NULL, 0, 0);

    //    Signature Algorithm ID
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 1);
    asn1_set_item(&t[i++], ASN_OBJECT_ID, NULL, 0, 0);

    //    Issuer Name
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 0);

    //      Validity period
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 2);
    //      Not Before
    asn1_set_item(&t[i++], ASN_UTCTIME, NULL, 0, 0);
    //      Not After
    asn1_set_item(&t[i++], ASN_UTCTIME, NULL, 0, 0);

    //  Subject name
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 0);

    //    Subject Public Key Info
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 0);

    //    Issuer Unique Identifier(optional)
    //    Subject Unique Identifier(optional)

    //    Extensions(optional)
    asn1_set_item(&t[i++], ASN_SE(3), NULL, 0, 1); // A3
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 0);
    //    ...

    //Certificate Signature Algorithm
    asn1_set_item(&t[i++], ASN_SEQUENCE, NULL, 0, 1);
    asn1_set_item(&t[i++], ASN_OBJECT_ID, NULL, 0, 0);

    //Certificate Signature (special case zero-len bitstring)
    asn1_set_bitstring(&t[i++], NULL, 0);

    cert->table = tableWorkspace;
    cert->length = i;

    return 0;
}


int x509_set_serial(ASN1_ITEM * table, unsigned char * serial, size_t * serialLen) {

    unsigned char path[] = { 1, 2, 0 };
    size_t nPath = sizeof(path);
    ASN1_ITEM * serialItem = NULL;
    int err = 0;

    err = asn1_find_item(table, path, &nPath, &serialItem);
    if (err) {
        return err;
    }

    asn1_set_integer(serialItem, serial, serialLen);

    return 0;
}


int x509_new_name(char * properties /*zero-terminated str*/, asn1_table * output) {

    size_t i = 0;
    size_t tableIndex = 0;

    // split the property string into individual 'name=value' strings
    unsigned char ** substrings;
    size_t count = 0;
    int err = os_str_split(properties, os_str_len(properties), '/', &count, &substrings);

    // if the property string's leading char is the delimiter /, the first substring will be empty
    // we won't count that as a property.
    if (os_str_len(substrings[0]) == 0) {
        count -= 1;
        i = 1;
    }

    unsigned char ** propertyNameValue;
    unsigned char * property;
    unsigned int tableLen;
    size_t count2 = 0;
    
    // create a big enough table - 4 items per property + 1 root sequence
    tableLen = (count * 4 + 1) * sizeof(ASN1_ITEM);
    ASN1_ITEM * table = mallocSD(tableLen);
    os_mem_set(table, 0, tableLen);

    asn1_set_item(&table[tableIndex++], ASN_SEQUENCE, NULL, 0, count);

    // handle each property
    for (; i <= count; i++)
    {
        property = substrings[i];

        err = os_str_split(property, os_str_len(property), '=', &count2, &propertyNameValue);

        x509_new_dn_property(propertyNameValue[0], propertyNameValue[1], &table[tableIndex]);

        tableIndex += 4;

        os_mem_del_set(propertyNameValue, 0);
    }

    // free the first split buffer
    os_mem_del_set(substrings, 0);

    output->table = table;
    output->length = tableIndex;

    return 0;
}


int x509_new_dn_property(char * prop, char * value, ASN1_ITEM * output) {

    char * oidStr;
    unsigned char * oidBytes;
    unsigned int oidBytesLen;
    size_t tableIndex = 0;

    ASN1_ITEM * table = mallocSD(4 * sizeof(ASN1_ITEM));
    os_mem_set(table, 0, 4 * sizeof(ASN1_ITEM));

    // get the oid str for this property (CN, OU, etc)
    asn1_lookup_property_oid(prop, &oidStr);

    // get the oid bytes from the string - need to free the oidBytes
    asn1_oid_str_to_bytes(oidStr, &oidBytes, &oidBytesLen);

    asn1_set_item(&table[tableIndex++], ASN_SET, NULL, 0, 1);
    asn1_set_item(&table[tableIndex++], ASN_SEQUENCE, NULL, 0, 2);
    asn1_set_item(&table[tableIndex++], ASN_OBJECT_ID, oidBytes, oidBytesLen, 0);
    asn1_set_item(&table[tableIndex++], ASN_PRINTABLE_STRING, value, os_str_len(value), 0);

    // this combines the separate data buffers
    asn1_clone_table(table, output);

    output = table;

    // free the oid
    os_mem_del_set(oidBytes, 0);

    return 0;
}





int x509_set_subject(asn1_table * cert, asn1_table subject)
{   // Sets the distinguished name DN for the Issuer or Subject on the cert
    // Assumes there is enough extra room in the table for the insert
    // Assumes the all the nitems properties in dnTable are correct

    int err = 0;
    asn1_table subjectDN;

    cert->length = asn1_get_child_count(cert->table) + 1;

    // find subject item in cert
    unsigned char certSubPath[3] = { 1, 6, 0 };
    err = asn1_find_by_path(cert, certSubPath, &subjectDN);

    size_t insertIndex = subjectDN.table - cert->table;

    size_t tailBytes = (cert->length - insertIndex) * sizeof(ASN1_ITEM);

    // move the tail items to make room for the new items
    // this may be an overlapping copy
    asn1_memmove(cert->table + insertIndex + subject.length, cert->table + insertIndex + 1, tailBytes);

    // copy the dn table into the table overwritting the insert item Sequence
    os_mem_cpy(cert->table + insertIndex, subject.table, subject.length * sizeof(ASN1_ITEM));

    cert->length = asn1_get_child_count(cert->table) + 1;

    return err;
}


int x509_set_issuer(asn1_table * cert, asn1_table issuer)
{   // Sets the distinguished name DN for the Issuer or Subject on the cert
    // Assumes there is enough extra room in the table for the insert
    // Assumes the all the nitems properties in dnTable are correct

    asn1_table issuertDN;

    cert->length = asn1_get_child_count(cert->table) + 1;

    // find subject item in cert
    unsigned char certSubPath[3] = { 1, 4, 0 };
    asn1_find_by_path(cert, certSubPath, &issuertDN);

    size_t insertIndex = issuertDN.table - cert->table;

    size_t tailBytes = (cert->length - insertIndex) * sizeof(ASN1_ITEM);

    // move the tail items to make room for the new items
    // this may be an overlapping copy
    asn1_memmove(cert->table + insertIndex + issuer.length, cert->table + insertIndex + 1, tailBytes);

    // copy the dn table into the table overwritting the insert item Sequence
    os_mem_cpy(cert->table + insertIndex, issuer.table, issuer.length * sizeof(ASN1_ITEM));

    cert->length = asn1_get_child_count(cert->table) + 1;

    return 0;
}


int x509_set_expiry(asn1_table table, size_t days) {

    // set cert expiry times
    unsigned int secs;
    unsigned int msecs;

    int err = util_get_time(&secs, &msecs);

    TIME_STR certStartTime;
    TIME_STR certEndTime;

    err = util_time_to_str(secs, msecs, &certStartTime);
    err = util_time_to_str(secs + (days * 24 * 60 * 60), msecs, &certEndTime);

    unsigned char pathT1[4] = { 1,5,1,0 };
    int n = 3;
    ASN1_ITEM * certTimeStartItem;
    err = asn1_find_item(table.table, pathT1, &n, &certTimeStartItem);

    certTimeStartItem->p_data = mallocSD(13);
    (certTimeStartItem + 1)->p_data = mallocSD(13);
    certTimeStartItem->len = 13;
    (certTimeStartItem + 1)->len = 13;
    asn1_time_to_UTCTime(&certStartTime, certTimeStartItem->p_data);
    asn1_time_to_UTCTime(&certEndTime, (certTimeStartItem + 1)->p_data);

    return 0;
}


int x509_new_public_key(ASN1_ITEM ** publicKeyItem, char * publicKeyOid, bool params, unsigned char * keyBytes0, size_t kbLen0, unsigned char * keyBytes1, size_t kbLen1) {

    // Public key consists of a:
    // SEQUENCE
    //   SEQUENCE
    //     OID
    //     ANY (optional)
    //   BITSTRING

    size_t i = 0;
    size_t count = (params) ? 5 : 4;

    // encode the oid string to bytes
    unsigned char * pkoid = NULL;
    size_t oidLen = 0;
    asn1_oid_str_to_bytes(publicKeyOid, &pkoid, &oidLen);

    // set the data for the bitstring
    ASN1_ITEM * bitstrTable = mallocSD(3 * sizeof(ASN1_ITEM));
    os_mem_set(bitstrTable, 0, 3 * sizeof(ASN1_ITEM));
    asn1_set_item(&bitstrTable[i++], ASN_SEQUENCE, NULL, 0, 2);
    asn1_set_item(&bitstrTable[i++], ASN_INTEGER, keyBytes0, kbLen0, 0);
    asn1_set_item(&bitstrTable[i++], ASN_OCTET_STRING, keyBytes1, kbLen1, 0);

    // create a big enough table - SEQ, SEQ, OID, PARAMS (optional), BITSTR
    ASN1_ITEM * table = mallocSD(count * sizeof(ASN1_ITEM));
    os_mem_set(table, 0, count * sizeof(ASN1_ITEM));
    i = 0;

    asn1_set_item(&table[i++], ASN_SEQUENCE, NULL, 0, 2);
    if (params) {
        asn1_set_item(&table[i++], ASN_SEQUENCE, NULL, 0, 2);
        asn1_set_item(&table[i++], ASN_OBJECT_ID, pkoid, oidLen, 0);
        asn1_set_item(&table[i++], ASN_NULL, NULL, 0, 0);
    }
    else {
        asn1_set_item(&table[i++], ASN_SEQUENCE, NULL, 0, 1);
        asn1_set_item(&table[i++], ASN_OBJECT_ID, pkoid, oidLen, 0);
    }
    asn1_set_item(&table[i], ASN_BIT_STRING, NULL, 0, 0);

    asn1_set_bitstring_from_asn1(&table[i++], bitstrTable);

    *publicKeyItem = table;

    return 0;
}


int x509_set_public_key(ASN1_ITEM * table, ASN1_ITEM * pkTable) {

    unsigned char path1[4] = { 1,7,0 };
    int n = 2;
    ASN1_ITEM * publicKeyItem;
    int err = asn1_find_item(table, path1, &n, &publicKeyItem);

    // determine the size of the main table
    size_t tableLen = asn1_get_child_count(&tableWorkspace[0]) + 1;

    // determine the size of the dnTable
    size_t pkTableLen = asn1_get_child_count(pkTable) + 1;

    // the index of the insert item in the main table
    size_t insertIndex = publicKeyItem - &tableWorkspace[0];

    // move the table items below the insertion point down
    os_mem_cpy(publicKeyItem + pkTableLen, publicKeyItem + 1, (tableLen - insertIndex) * sizeof(ASN1_ITEM));

    // copy the dn table into the table overwritting the insert item Sequence
    os_mem_cpy(publicKeyItem, pkTable, pkTableLen * sizeof(ASN1_ITEM));

    return 0;
}


int x509_new_subject_key_identifier2(asn1_table publicKeyItem, asn1_table * output) {

    //SEQUENCE(2 elem)
    //    OBJECT IDENTIFIER2.5.29.14subjectKeyIdentifier(X.509 extension)
    //    OCTET STRING(1 elem)
    //        OCTET STRING(20 byte) 562D4764E90027D17A45D23D7EAF132141364380

    size_t i = 0;

    // encode the oid string to bytes
    char * oidStr = "2.5.29.14";
    unsigned char * skioid = NULL;
    size_t oidLen = 0;
    asn1_oid_str_to_bytes(oidStr, &skioid, &oidLen);

    // Hash the public key item data into a buffer with an octet string header
    unsigned char * data = mallocSD(20 + 2); // sha-1 len + 2 for octet string header
    data[0] = 4;  //OCTET_STRING
    data[1] = 20;
    int err = hash_sha1(0, publicKeyItem.table->len, publicKeyItem.table->p_data + 1, NULL, data + 2);

    // set the data for the bitstring
    ASN1_ITEM * skiTable = mallocSD(3 * sizeof(ASN1_ITEM));
    os_mem_set(skiTable, 0, 3 * sizeof(ASN1_ITEM));
    asn1_set_item(&skiTable[i++], ASN_SEQUENCE, NULL, 0, 2);
    asn1_set_item(&skiTable[i++], ASN_OBJECT_ID, skioid, oidLen, 0);
    asn1_set_item(&skiTable[i++], ASN_OCTET_STRING, data, 22, 0);

    output->table = skiTable;
    output->length = 3;

    return 0;
}


int x509_set_subject_key_identifier(ASN1_ITEM * extensions, ASN1_ITEM * skiTable) {

    // determine the size of the main table
    size_t tableLen = asn1_get_child_count(&tableWorkspace[0]) + 1;

    // determine the size of the skiTable
    size_t skiTableLen = asn1_get_child_count(skiTable) + 1;

    // the index of the insert item in the main table
    size_t insertIndex = (extensions - &tableWorkspace[0]) + 1;

    // move the table items below the insertion point down
    os_mem_cpy(extensions + skiTableLen + 1, extensions + 1, (tableLen - insertIndex) * sizeof(ASN1_ITEM));

    // copy the dn table into the table overwritting the insert item Sequence
    os_mem_cpy(extensions + 1, skiTable, skiTableLen * sizeof(ASN1_ITEM));

    extensions->nitems += 1;

    return 0;
}


int x509_new_basic_constraints2(unsigned int certType, asn1_table* output) {

    //SEQUENCE(2 elem)
    //    OBJECT IDENTIFIER  2.5.29.19 
    //    OCTET STRING(1 elem)
    //        SEQUENCE(1 elem)
    //            BOOLEAN true
    // 30 03 01 01 FF

    size_t i = 0;

    // encode the oid string to bytes
    char * oidStr = "2.5.29.19";
    unsigned char * bcoid = NULL;
    size_t oidLen = 0;
    asn1_oid_str_to_bytes(oidStr, &bcoid, &oidLen);

    unsigned char * data = mallocSD(5);
    data[0] = 0x30;  data[1] = 3; data[2] = 1; data[3] = 1; data[4] = (certType == 0) ? 0xFF : 0;

    // set the data for the bitstring
    ASN1_ITEM * skiTable = mallocSD(3 * sizeof(ASN1_ITEM));
    os_mem_set(skiTable, 0, 3 * sizeof(ASN1_ITEM));
    asn1_set_item(&skiTable[i++], ASN_SEQUENCE, NULL, 0, 2);
    asn1_set_item(&skiTable[i++], ASN_OBJECT_ID, bcoid, oidLen, 0);
    asn1_set_item(&skiTable[i++], ASN_OCTET_STRING, data, 5, 0);

    output->table = skiTable;
    output->length = 3;

    return 0;
}


int x509_set_basic_constraints(ASN1_ITEM * extensions, ASN1_ITEM * bcTable) {

    // determine the size of the main table
    size_t tableLen = asn1_get_child_count(&tableWorkspace[0]) + 1;

    // determine the size of the bcTable
    size_t skiTableLen = asn1_get_child_count(bcTable) + 1;

    // the index of the insert item in the main table
    size_t insertIndex = (extensions - &tableWorkspace[0]) + 1;

    // move the table items below the insertion point down
    os_mem_cpy(extensions + skiTableLen + 1, extensions + 1, (tableLen - insertIndex) * sizeof(ASN1_ITEM));

    // copy the dn table into the table overwritting the insert item Sequence
    os_mem_cpy(extensions + 1, bcTable, skiTableLen * sizeof(ASN1_ITEM));

    extensions->nitems += 1;

    return 0;
}


int x509_set_signature_alg(asn1_table cert, char * oidStr) {

    unsigned char path[4] = { 2,1,0 };
    unsigned char * algOid = NULL;
    size_t oidLen = 0;
    asn1_table signatureAlgItem;

    asn1_find_by_path(&cert, path, &signatureAlgItem);

    asn1_oid_str_to_bytes(oidStr, &algOid, &oidLen);
    asn1_set_item(signatureAlgItem.table, ASN_OBJECT_ID, algOid, oidLen, 0);

    return 0;
}


int x509_set_alg_id(char * oidStr) {

    // encode the oid string to bytes
    unsigned char * algOid = NULL;
    size_t oidLen = 0;
    asn1_oid_str_to_bytes(oidStr, &algOid, &oidLen);
    asn1_set_item(&tableWorkspace[6], ASN_OBJECT_ID, algOid, oidLen, 0);

    return 0;
}


int x509_set_signature(asn1_table cert, unsigned char * signature, unsigned int signatureLen) {

    // find signature property
    unsigned char path[4] = { 3, 0 };
    asn1_table certSignature;
    int err = 0;

    if ((err = asn1_find_by_path(&cert, path, &certSignature)) != 0) {
        return err;
    }

    if ((err = asn1_set_bitstring(certSignature.table, signature, signatureLen)) != 0) {
        return err;
    }

    asn1_fix_item_lengths(cert.table);

    return 0;
}


int x509_create_cert(
    int certType,
    asn1_table * cert,
    unsigned char * serial,
    size_t serialLen,
    char * algorithmOid,
    char * issuerDN,
    char * subjectDN,
    size_t daysUntilExpired,
    char * publicKeyOid,
    unsigned char * publicKeyBytes0,
    size_t publicKeyLen0) {

    int err = 0;

    char * beginTag = "-----BEGIN CERTIFICATE REQUEST-----";
    char * endTag = "-----END CERTIFICATE REQUEST-----";

    asn1_table newCert;
    asn1_table certSubject;
    asn1_table certIssuer;
    asn1_table subjectTable;
    asn1_table issuerTable;
    asn1_table subjectPK;
    asn1_table csrTable;

    // create an empty x509 cert with basic properties
    err = x509_new_empty_certificate(&newCert);

    // set the serial
    err = x509_set_serial(newCert.table, serial, &serialLen);

    // set the alg id
    err = x509_set_alg_id(algorithmOid);

    // find subject item in cert
    unsigned char certSubPath[3] = { 1, 6, 0 };
    asn1_find_by_path(&newCert, certSubPath, &certSubject);

    // find subject item in cert
    unsigned char certIssPath[3] = { 1, 4, 0 };
    asn1_find_by_path(&newCert, certIssPath, &certIssuer);

    // handle the subject name depending on the cert type
    if (certType == 0 || certType == 1) {

        // create a new DN for the subject
        err = x509_new_name(subjectDN, &subjectTable);

        // set the subject. inserts the DN table above into the main table
        err = x509_set_subject(&newCert, subjectTable);
        asn1_free_table(subjectTable);

    }
    else {

        err = asn1_decode_pem(beginTag, endTag, subjectDN, &csrTable);

        // find subject item in csr
        unsigned char csrSubject[3] = { 1, 2, 0 };
        err = asn1_get_sub_table_by_path(&csrTable, csrSubject, &subjectTable);

        // set the subject. inserts the DN table above into the main table
        err = x509_set_subject(&newCert, subjectTable);

        // find public key item in csr
        unsigned char csrPK[3] = { 1, 3, 0 };
        err = asn1_get_sub_table_by_path(&csrTable, csrPK, &subjectPK);

        // set the public key in the cert
        err = x509_set_public_key(newCert.table, subjectPK.table);

    }

    // create a new DN for the issuer
    err = x509_new_name(issuerDN, &issuerTable);

    // set the issuer. inserts the DN table above into the main table
    err = x509_set_issuer(&newCert, issuerTable);

    // set the expiry date-times
    err = x509_set_expiry(newCert, daysUntilExpired);

    if (certType == 0 || certType == 1) {

        // create a new public key table
        err = x509_new_public_key(&subjectPK.table, publicKeyOid, false, "\0", 1, publicKeyBytes0, publicKeyLen0);

        // set the public key in the cert
        err = x509_set_public_key(newCert.table, subjectPK.table);
    }

    // create a subject public key identifier
    asn1_table ski;
    err = x509_new_subject_key_identifier2(subjectPK, &ski);

    // create a basic constraint
    asn1_table bc;
    err = x509_new_basic_constraints2(certType, &bc);

    // find the extensions property
    asn1_table extensions;
    asn1_find_by_path(&newCert, PATHS_EXTENSIONS, &extensions);

    // add the basic constraint and ski to the extensions
    err = x509_set_basic_constraints(extensions.table, bc.table);
    err = x509_set_subject_key_identifier(extensions.table, ski.table);

    err = x509_set_signature_alg(newCert, algorithmOid);

    newCert.length = asn1_get_child_count(newCert.table) + 1;

    //asn1_fix_item_lengths(newCert.table);

    *cert = newCert;

    return err;
}
