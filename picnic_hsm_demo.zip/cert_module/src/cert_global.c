/*! @file cert_global.c
 *  @brief Cert Module global file
 *
 *  This file is part of the Cert HSM module.
 *  This file contains structures and functions required
 *  required by the HSM.
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


/* define before including cert.h - identifies this as internal */
#define _CERT_C_INT_


#include <module_1.5.h>
#include <adm.h>
#include "cert.h"
#include "cert_ext.h"


/* module id structure */
FILE_CONST T_MODULE_INFO Module_info =
{
  MODULE_INFO_TAG,
  CERT_MDL_NAME,
  CS2_U32_TO_BIG_ENDIAN(CERT_MDL_ID),
  CS2_U32_TO_BIG_ENDIAN(CERT_MDL_VERSION),
  CERT_MDL_NAMEX
};


/* public interface */
FILE_CONST T_CERT_TABLE_PUB Module_pub =
{
    /* required by HSM */
    NULL,
    cert_start,
    cert_stop,
    cert_pre_replace,
    cert_pre_delete,
    NULL,
    &Module_info,
};


/* references to other HSM modules */
#define MODULE_NEEDS_EXT_REFS
MDL_GLOBAL T_OS_MDL_HDL P_SMOS;
MDL_GLOBAL T_OS_MDL_HDL P_CMDS;
MDL_GLOBAL T_OS_MDL_HDL P_UTIL;
MDL_GLOBAL T_OS_MDL_HDL P_DB;
MDL_GLOBAL T_OS_MDL_HDL P_ASN1;
MDL_GLOBAL T_OS_MDL_HDL P_HASH;
MDL_GLOBAL T_OS_MDL_HDL P_PICNIC;

FILE_CONST T_MODULE_LINK_TAB Module_link_tab[] =
{
  // handle      name.       version    flags
  {  &P_CMDS,    "CMDS",     0,         0  },
  {  &P_UTIL,    "UTIL",     0,         0  },
  {  &P_DB,      "DB",       0,         0  },
  {  &P_ASN1,    "ASN1",     0,         0  },
  {  &P_HASH,    "HASH",     0,         0  },
  {  &P_PICNIC,  "PICNIC",   0,         0  },
  /*  marks end of table                  */
  {  NULL,       "",         0,         0  }
};


/* Cert external interface */
#define MODULE_HAS_EXT_INTERFACE

FILE_CONST P_CMDS_FCT Module_func_tab[] =
{
    cert_ext_generate_cert,             // SFC = 0
    cert_ext_verifyCertSignature,       // SFC = 1
    cert_ext_generateCAKeyPair          // SFC = 2
};


/* called when module starts */
int cert_start(T_OS_MDL_HDL p_smos, OS_FILE_HANDLE p_spf, void *p_coff_mem)
{
    P_SMOS = p_smos;
    return module_start(p_coff_mem);
}


/* module_init_1.5.c uses these to initialize the module */
#define MODULE_INIT_TASK_STACK_SIZE    0x1000
#define MODULE_INIT_TASK_FUNCTION      cert_init
#define MODULE_INIT_TASK_NAME          "INIT_CERT"


int cert_init(void)
{
    int err;
    INIT_STAT DB_INFO db_info = { DB_INFO_TAG, 8, 0x100000 };

    /* open the internal cert key database - creates if needed */
    P_db = NULL;
    if ((err = db_open("cert", DB_CREAT, &db_info, &P_db)) != 0)
    return err;

    return(0);
}


int cert_stop(void)
{
    return(0);
}


int cert_pre_replace(void)
{
    return(0);
}


int cert_pre_delete(void)
{
    return(0);
}


#undef _CERT_C_INT_

#include MODULE_INIT_C
