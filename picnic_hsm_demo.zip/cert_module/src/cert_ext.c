/*! @file cert_ext.c
 *  @brief Implementation of the Cert module external API
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#include <os_log.h>
#include <db.h>
#include <adm.h>

#include "picnic.h"
#include "cert.h"
#include "cert_b64.h"
#include "cert_asn1.h"
#include "cert_x509.h"
#include "cert_int.h"
#include "cert_ext.h"


#define CMDS_MAX_CMD_SIZE 0x40000
#define SERIAL_LEN 9
#define BEGIN_CERT_TAG "-----BEGIN CERTIFICATE-----"
#define END_CERT_TAG "-----END CERTIFICATE-----"

typedef struct {
    ASN1_ITEM * table;
    unsigned int length;
} asn1table;


int cert_ext_generateCAKeyPair(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd) {

    int err = 0;
    char * keyPairName = "ca.key";
    unsigned char *p_answ = NULL;

    struct
    {
        unsigned int params;
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "u4", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    unsigned int l_sec;
    unsigned char * p_sec;
    unsigned int l_pub;
    unsigned char * p_pub;

    // generate key
    if ((err = picnic_pub_keygen(cmd.params, &l_sec, &p_sec, &l_pub, &p_pub) != 0))
        goto cleanup;

    db_delete(P_db, keyPairName);

    err = db_insert(P_db, keyPairName, l_pub, p_pub, l_sec, p_sec);

    if ((err = cmds_alloc_answ(p_hdl, l_pub, &p_answ)) != 0)
        goto cleanup;

    os_mem_cpy(p_answ, p_pub, l_pub);

cleanup:

    return err;
}


int cert_ext_generate_cert(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{
    char * keyPairName = "ca.key";
    unsigned char *p_answ = NULL;

    int err = 0;
    char * subjectPropertyString = NULL;
    char * issuerPropertyString = NULL;

    unsigned int    l_ca_pk;
    unsigned char * p_ca_pk;
    unsigned int    l_ca_sk;
    unsigned char * p_ca_sk;

    char * begin = BEGIN_CERT_TAG;
    char * end = END_CERT_TAG;

    unsigned char serial[SERIAL_LEN];
    asn1_table cert;

    size_t messageSize;
    unsigned char * message = NULL;

    unsigned char * signature = NULL;
    size_t signatureLen = 0;

    size_t  b64CertLen;
    char * b64Cert;

    struct
    {
        unsigned int  caCertRequest;
        unsigned int  days;
        unsigned int  l_name;
        char *p_name;
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "u2u2v2", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    subjectPropertyString = cmd.p_name;

    if (cmd.caCertRequest == 0) {
        // self-signed CA cert. issuer and subject string are the same.
        issuerPropertyString = cmd.p_name;
        saveCAName("FLASH\\caName.txt", subjectPropertyString);
    }
    else if (cmd.caCertRequest == 1) {
        // CA signed EE cert. issuer read from file. subject from user.
        err = loadCAName("FLASH\\caName.txt", &issuerPropertyString);
    }
    else if (cmd.caCertRequest == 2) {
        // CA signed EE cert. issuer read from file. subject from CSR.
        err = loadCAName("FLASH\\caName.txt", &issuerPropertyString);
    }
    else {
        err = -1;
        goto cleanup;
    }

    // Load CA keys from DB
    loadKeys(keyPairName, &l_ca_pk, &p_ca_pk, &l_ca_sk, &p_ca_sk);

    err = util_get_real_rnd(serial, SERIAL_LEN);

    // the new cert table is created in the pre-allocated tableWorkspace array (x509.h)
    err = x509_create_cert(cmd.caCertRequest,
        &cert, serial, SERIAL_LEN, OID_PICNIC, issuerPropertyString, subjectPropertyString,
        cmd.days, OID_PICNIC, p_ca_pk, l_ca_pk);


    asn1_encode_item(&cert.table[1], &message, &messageSize);   // free message when done

    // sign the signature data
    err = getCertSignature(l_ca_pk, p_ca_pk, l_ca_sk, p_ca_sk, message, messageSize, &signature, &signatureLen);

    if (err != 0) {
        os_log_print("picnic_sign failed\n");
        return err;
    }

    err = x509_set_signature(cert, signature, signatureLen);

    // we can free the signature. it was copied by set_signature
    os_mem_del(signature);
    os_mem_del(message);


    // encode the entire cert to return to host
    err = asn1_encode_item(cert.table, &message, &messageSize);
    b64CertLen = (messageSize / 3) * 4 + 4;
    b64Cert = os_mem_new(b64CertLen, OS_MEM_TYPE_SD);
    encodeToBase64(message, messageSize, b64Cert, &b64CertLen);

    // walk the table freeing malloc'd data
    //freeTable(cert.table);

    // allocate mem for the answer with the begin and end tags
    if ((err = cmds_alloc_answ(p_hdl, os_str_len(begin) + b64CertLen + os_str_len(end), &p_answ)) != 0)
        goto cleanup;

    os_mem_cpy(p_answ, begin, os_str_len(begin));
    os_mem_cpy(p_answ + os_str_len(begin), b64Cert, b64CertLen);
    os_mem_cpy(p_answ + os_str_len(begin) + b64CertLen, end, os_str_len(end));

    os_mem_del(message);
    os_mem_del(b64Cert);

cleanup:

    return 0;
}


int cert_ext_verifyCertSignature(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd) {

    asn1_table table;
    asn1_table signature;

    unsigned char *p_answ = NULL;
    int err = 0;
    char * beginTag = BEGIN_CERT_TAG;
    char * endTag = END_CERT_TAG;
    unsigned int messageLen;
    unsigned char sigpath[2] = { 3, 0 };

    unsigned int    l_ca_pk;
    unsigned char * p_ca_pk;
    unsigned int    l_ca_sk;
    unsigned char * p_ca_sk;

    struct
    {
        unsigned int  l_cert;
        unsigned char *p_cert;
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "v4", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    // decode the cert
    if ((err = asn1_decode_pem(beginTag, endTag, cmd.p_cert, &table)) != 0)
        goto cleanup;

    // extract the signature
    if ((err = asn1_get_sub_table_by_path(&table, sigpath, &signature)) != 0)
        goto cleanup;

    // Load CA keys from DB
    loadKeys("ca.key", &l_ca_pk, &p_ca_pk, &l_ca_sk, &p_ca_sk);

    // verify the cert using the CA public key and the signature
    messageLen = (table.table[1].p_data - table.table[0].p_data) + table.table[1].len;
    err = picnic_pub_verify(l_ca_pk, p_ca_pk, messageLen, table.table[0].p_data, signature.table->len - 1, signature.table->p_data + 1);

    // allocate mem for the answer with the begin and end tags
    cmds_alloc_answ(p_hdl, sizeof(int), &p_answ);
    os_mem_cpy(p_answ, &err, sizeof(int));

cleanup:

    return err;
}
