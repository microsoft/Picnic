/*! @file cert_int.c
 *  @brief Internal (private) Cert Module functions
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#include <load_store.h>
#include <stype.h>
#include <memutil.h>

#include <os_mem.h>
#include <os_str.h>
#include <os_log.h>
#include <os_task.h>
#include <os_file.h>

#include <util.h>
#include <db.h>
#include <asn1.h>
#include <adm.h>
#include <hash.h>

#include "picnic.h"
#include "cert.h"
#include "cert_b64.h"
#include "cert_asn1.h"
#include "cert_x509.h"


MDL_GLOBAL DB *P_db;


typedef unsigned char byte_t;


int getCertSignature(unsigned int l_pk, unsigned char *p_pk, unsigned int l_sk, unsigned char *p_sk,
    unsigned char * message, unsigned int messageLen, unsigned char ** p_signature,
    unsigned int * p_l_signature) {

    int ret = 0;

    ret = picnic_pub_sign(l_sk, p_sk, messageLen, message, p_l_signature, p_signature);
    if (ret != 0) {
        os_log_print("picnic_sign failed\n");
        return ret;
    }

    // uncomment for verification during debugging
    //ret = picnic_pub_verify(l_pk, p_pk, messageLen, message, *p_l_signature, *p_signature);
    //if (ret != 0) {
    //    os_log_print("picnic_verify failed\n");
    //    return ret;
    //}

    return 0;
}


int loadKeys(char * keyPairName, unsigned int * p_l_pk, unsigned char ** pp_pk, unsigned int * p_l_sk, unsigned char ** pp_sk) {

    int err = 0;
    void * pkdb;
    void * skdb;

    if ((err = db_find(P_db, DB_EQUAL | DB_LOCK, keyPairName, p_l_pk, &pkdb, p_l_sk, &skdb)) != 0)
        goto cleanup;

    // Allocate memory for the keys - we're copying the keys from the db cache
    // locking it during the copy and releasing it after.  
    *pp_sk = (unsigned char *)os_mem_new(*p_l_sk, OS_MEM_TYPE_SECURE);
    os_mem_cpy(*pp_sk, skdb, *p_l_sk);

    *pp_pk = (unsigned char *)os_mem_new(*p_l_pk, OS_MEM_TYPE_SECURE);
    os_mem_cpy(*pp_pk, pkdb, *p_l_pk);

    db_release(P_db, keyPairName, 0);

    // validate the keys
    if ((err = picnic_pub_keychk(*p_l_sk, *pp_sk, *p_l_pk, *pp_pk)) != 0) {
        os_log_print("picnic_pub_validate_keypair failed\n.");
        goto cleanup;
    }
    return 0;

cleanup:

    return err;
}


int saveCAName(char * filename, char * properties) {
    /* save the CA distinguished name to file for later use */

    int err = 0;

    if (os_file_access(filename, OS_FILE_EXIST) == 0)
        os_file_unlink(filename);

    OS_FILE_HANDLE  fh = OS_FILE_INVALID_HANDLE;

    if ((fh = os_file_open(filename, OS_FILE_O_CREATE | OS_FILE_O_RDWR | OS_FILE_O_TEXT)) == OS_FILE_INVALID_HANDLE) {
        err = os_task_errno_get();
        goto cleanup;
    }

    os_file_write(fh, properties, os_str_len(properties) + 1);

    os_file_close(fh);
    fh = OS_FILE_INVALID_HANDLE;

cleanup:

    return err;
}


int loadCAName(char * filename, char ** name) {
    /* load the CA distinguished name from file */

    int             err = 0;
    unsigned int    l_file;
    char *          caCertData;
    OS_FILE_HANDLE  fh = OS_FILE_INVALID_HANDLE;

    if ((fh = os_file_open(filename, OS_FILE_O_RDWR | OS_FILE_O_TEXT)) == OS_FILE_INVALID_HANDLE) {
        err = os_task_errno_get();
        goto cleanup;
    }

    l_file = os_file_length(fh);

    caCertData = os_mem_new(l_file, OS_MEM_TYPE_SD);

    os_file_read(fh, caCertData, l_file);

    os_file_close(fh);

    *name = caCertData;

cleanup:

    return err;
}
