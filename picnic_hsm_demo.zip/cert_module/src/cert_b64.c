/*! @file cert_b64.c
 *  @brief Cert module Base64 helper
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#include <stddef.h>


void decodeBase64(char * base64String, unsigned int length, char * buffer, unsigned int * bufferLen) {

    unsigned char decodingTable[80] = { 62,0,0,0,63,52,53,54,55,56,57,58,59,60,61,0,0,0,64,0,0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,0,0,0,0,0,0,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51 };

    unsigned char enc1, enc2, enc3, enc4, char1, char2, char3;

    size_t index = 0;
    size_t i;

    for (i = 0; i < length; i += 4)
    {
        // strip out trash
        if (base64String[i] < 43) {
            continue;
        }

        enc1 = decodingTable[base64String[i] - 43];
        enc2 = decodingTable[base64String[i + 1] - 43];
        enc3 = decodingTable[base64String[i + 2] - 43];
        enc4 = decodingTable[base64String[i + 3] - 43];

        char1 = (enc1 << 2) | (enc2 >> 4);
        char2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        char3 = ((enc3 & 3) << 6) | enc4;

        buffer[index++] = char1;

        if (enc3 != 64) {
            buffer[index++] = char2;
        }

        if (enc4 != 64) {
            buffer[index++] = char3;
        }
    }

    *bufferLen = index;

    return;
}


void encodeToBase64(unsigned char * bytes, unsigned int length, char * buffer, unsigned int * bufferLen) {

    char * encodingChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

    unsigned int char1, char2, char3;

    size_t set = 0;
    size_t outPtr = 0;
    size_t i;

    for (i = 0; i < length; i++)
    {
        switch (set)
        {
        case 0:
            char1 = bytes[i];
            set++;
            break;
        case 1:
            char2 = bytes[i];
            set++;
            break;
        case 2:
            char3 = bytes[i];
            buffer[outPtr++] = encodingChars[char1 >> 2];
            buffer[outPtr++] = encodingChars[((char1 & 0x3) << 4) | (char2 >> 4)];
            buffer[outPtr++] = encodingChars[((char2 & 0xF) << 2) | (char3 >> 6)];
            buffer[outPtr++] = encodingChars[char3 & 0x3F];
            set = 0;
            break;
        default:
            break;
        }
    }

    if (set == 1) {
        // two char padding
        buffer[outPtr++] = encodingChars[char1 >> 2];
        buffer[outPtr++] = encodingChars[(char1 & 0x3) << 4];
        buffer[outPtr++] = encodingChars[64];
        buffer[outPtr++] = encodingChars[64];
    }

    if (set == 2) {
        buffer[outPtr++] = encodingChars[char1 >> 2];
        buffer[outPtr++] = encodingChars[((char1 & 0x3) << 4) | (char2 >> 4)];
        buffer[outPtr++] = encodingChars[(char2 & 0xF) << 2];
        buffer[outPtr++] = encodingChars[64];
    }

    *bufferLen = outPtr;
}
