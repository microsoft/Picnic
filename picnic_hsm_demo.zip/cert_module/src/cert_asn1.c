/*! @file cert_asn1.c
 *  @brief Cert module ASN1 helper functions
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#include "cert_asn1.h"
#include "cert.h"
#include "cert_b64.h"
#include <os_log.h>

void freeTable(ASN1_ITEM * table) {

    unsigned int len = asn1_get_child_count(table);
    unsigned int size = 0;
    int i;
    int err;

    for (i = len; i >= 0; i--)
    {
        err = os_mem_check(table[i].p_data, &size);

        if (table[i].p_data != NULL && err == 0) { // && !ASN_IS_STRUCT(table[i].tag)) {
            os_mem_del(table[i].p_data);
        }

        if(err != 0) {
            err = 0;
        }
    }
}

/* prints out an array as a hex string (for debugging) */
void printHex(const char* s, unsigned char * data, unsigned int len)
{
    size_t i;
    os_log_print("%s: ", s);
    for (i = 0; i < len; i++) {
        os_log_print("%02X", data[i]);
    }
    os_log_print("\n");
}


int asn1_delete_item(asn1_table * table, ASN1_ITEM * toDelete) {

    size_t deleteIndex = toDelete - table->table;

    size_t deleteCount = asn1_get_child_count(toDelete) + 1;

    size_t itemSize = sizeof(ASN1_ITEM);

    size_t tailLen = (table->length - deleteCount - deleteIndex) * itemSize;

    // move the tail up to fill the deleted items
    os_mem_cpy(table->table + deleteIndex, table->table + deleteIndex + deleteCount, tailLen);

    // clear old tail data
    os_mem_set(table->table + deleteIndex + tailLen, 0, deleteCount * itemSize);

    table->length = asn1_get_child_count(table->table) + 1;

    return 0;
}


int asn1_get_child_count(ASN1_ITEM * parent) {
    /*  Returns the number of decendnats an ASN1_ITEM item has.
        Not just the immediate children. */

    size_t children = parent->nitems;
    size_t i = 1;

    while (i <= children) {
        children += parent[i].nitems;
        i += 1;
    }

    return children;
}


int asn1_fix_item_lengths(ASN1_ITEM * parent) {

    ASN1_ITEM * ptr;
    size_t len = 0;
    size_t tlen = 0;

    int i = asn1_get_child_count(parent);

    for (; i >= 0; i--) {
        ptr = &(parent[i]);

        if (ASN_IS_STRUCT(ptr->tag) != 0) {
            ptr->len = len;
            tlen = asn1_get_item_total_len(ptr);
            len = tlen;
        }
        else
        {
            tlen = asn1_get_item_total_len(ptr);
            if (ptr->tag == ASN_BIT_STRING) {
                tlen += 1;
            }

            if (ptr->tag == ASN_INTEGER && ptr->p_data != NULL && ptr->p_data[0] & 0x80) tlen += 1;

            len += tlen;
        }

    }

    return len;
}


int asn1_get_item_total_len(ASN1_ITEM * parent) {
    /* The ASN1_ITEM.len filed give the length of it child data and does not include
       its own size in the length.  */

    size_t count = 0;
    unsigned int len = parent->len;

    if (len < 127) {
        return len + (parent->tag == ASN_NULL ? 1 : 2); // tag + 1-byte size
    }

    while (len > 0) { len >>= 8;  count++; }

    return parent->len + count + 2; // tag + lenByteCount + lenBytes + dataLen
}


int asn1_memmove(void * dest, void * source, unsigned int length) {
    /* os_mem_cpy doesn't handle overlapping memory moves on the hsm. */
    void * temp = NULL;

    temp = mallocSD(length);
    if (NULL == temp) return -1;

    os_mem_cpy(temp, source, length);
    os_mem_cpy(dest, temp, length);
    os_mem_del_set(temp, 0);

    return 0;
}


int asn1_encode_item(ASN1_ITEM * item, unsigned char ** buffer, size_t * bufferLen) {
    /* Encodes an ASN1_ITEM item with children. The len and nitems fields need to be correct.

       The asn1_encode() function has a couple of problems.
       First, it corrupts the ASN1_ITEM table during encoding. So if you want to
       continue to use the table, you need to copy it before encoding. You could also
       asn1_decode() your encoding back into your original table to restore it.
       The second problems, is asn1_encode fills you buffer from the back.
       So if you pass a buffer that's larger than the encoding, you will get a pointer
       back that is some other place than the start of your buffer, causing a error
       when you eventually try to free it.
       To work around these problems, we encode a copy of our table to keep from
       corrupting it. Then we move our encoding results to the front of the buffer
       so we maintain the same pointer we got from malloc. */

       /* Determine the items in the table and its length in bytes. */
    size_t totalTagCount = asn1_get_child_count(item) + 1;
    size_t tableBytes = totalTagCount * sizeof(ASN1_ITEM);

    // copy the ASN1_ITEM table
    ASN1_ITEM * temp = mallocSD(tableBytes);
    os_mem_cpy(temp, item, tableBytes);

    // create a results buffer. asn1_fix_item_lengths() returns the length needed.
    // currently, asn1_fix_item_lengths returns a length that is a little too big.
    *bufferLen = asn1_fix_item_lengths(item);
    *buffer = mallocSD(*bufferLen);
    void * bufferStart = *buffer;

    // encode the copied table to our buffer. free our temp table when done.
    int err = asn1_encode(temp, totalTagCount, 0, buffer, bufferLen);
    os_mem_del_set(temp, 0);

    // move the buffer results to the front of the buffer (if needed)
    if (bufferStart != *buffer) {
        asn1_memmove(bufferStart, *buffer, *bufferLen);
        *buffer = bufferStart;
    }

    return err;
}


int asn1_clone_table(ASN1_ITEM * item, ASN1_ITEM * clone) {
    /* makes a clone of a table and its data */

    unsigned char * buffer;
    size_t bufferLen;
    int err = 0;
    int cloneLen;

    err = asn1_encode_item(item, &buffer, &bufferLen);

    err = asn1_decode(buffer, bufferLen, 0, clone, &cloneLen);

    return err;
}


int asn1_decode_pem(char * beginTag, char * endTag, unsigned char * data, asn1_table * tableOut) {

    ASN1_ITEM  * table;
    int err = 0;

    // find the begin and end tags
    char * begin = os_str_str(data, beginTag) + os_str_len(beginTag);
    char * end = os_str_str(data, endTag);

    // convert the base64 to bytes. 4 b64chars per 3 bytes of data.
    size_t b64Len = os_str_len(data) - os_str_len(beginTag) - os_str_len(endTag);
    unsigned char * buffer = os_mem_new((b64Len / 4) * 3, OS_MEM_TYPE_SD);
    decodeBase64(begin, b64Len, buffer, &b64Len);

    // decode the cert stream to an ASN1 Table
    unsigned int tableSize = 0;

    // get the size of the buffer need with a NULL output buffer
    if ((err = asn1_decode(buffer, b64Len, 0, NULL, &tableSize)) != 0)
        return err;

    table = os_mem_new(tableSize * sizeof(ASN1_ITEM), OS_MEM_TYPE_SD);

    // encode to the table buffer. Note: don't free buffer
    // the table has pointers to data in buffer.
    if ((err = err = asn1_decode(buffer, b64Len, 0, table, &tableSize)) != 0)
        return err;

    tableOut->table = table;
    tableOut->length = tableSize;

    return 0;
}


ASN1_ITEM * asn1_create_item(unsigned int tag, unsigned char * initialValue, unsigned int * initialValueLen) {

    ASN1_ITEM * newItem = os_mem_new(sizeof(ASN1_ITEM), OS_MEM_TYPE_SD);

    newItem->tag = tag;
    newItem->nitems = 0;

    // no initial value set, not length = set as NULL
    if (NULL == initialValue && 0 == *initialValueLen) {
        newItem->p_data = NULL;
        newItem->len = 0;
    }

    // no initial value, but length set = point p_data at empty buffer of length
    if (NULL == initialValue && 0 < *initialValueLen) {
        newItem->p_data = os_mem_new(*initialValueLen, OS_MEM_TYPE_SD);
        newItem->len = *initialValueLen;
        os_mem_set(newItem->p_data, 0, *initialValueLen);
    }

    // copy the initial value to p_data and set the len
    if (NULL != initialValue && 0 < *initialValueLen) {
        newItem->p_data = os_mem_new(*initialValueLen, OS_MEM_TYPE_SD);
        newItem->len = *initialValueLen;
        os_mem_cpy(newItem->p_data, initialValue, *initialValueLen);
    }

    return newItem;
}


int asn1_copyItem(ASN1_ITEM * itemToCopy, ASN1_ITEM** copyTable, size_t * copyTableLen, bool copyData) {
    /* Creates a copy of an item (including its children) to a new table */

    unsigned int childCount = asn1_get_child_count(itemToCopy);
    unsigned int newTableLen = (childCount + 1) * sizeof(ASN1_ITEM);
    size_t i = 0;
    ASN1_ITEM* newTable = *copyTable;

    newTable = mallocSD(newTableLen);
    os_mem_cpy(newTable, itemToCopy, newTableLen);

    // copy the data to a new buffer if requested.
    if (copyData) {

        for (i = 0; i <= childCount; i++)
        {
            (newTable + i)->p_data = mallocSD((newTable + i)->len);
            os_mem_cpy((newTable + i)->p_data, (itemToCopy + i)->p_data, (itemToCopy + i)->len);
        }
    }

    *copyTableLen = childCount + 1;

    return 0;
}


void asn1_set_item(ASN1_ITEM * item, unsigned int tag, unsigned char * data, unsigned int dataLen, unsigned int childCount) {

    item->nitems = childCount;
    item->tag = tag;

    item->p_data = data;
    item->len = dataLen;

    return;
}


void asn1_set_integer(ASN1_ITEM * item, unsigned char * data, unsigned int * dataLen) {
    /* set the value of an integer. handle the appending of a zero if needed.
       DER encoded integers will append a leading zero if the high-order bit is set.
       This allows decoders to know the integer is positive even though the bit would signify it was negative. */

    size_t offset = (data[0] & 128) ? 1 : 0;
    size_t bufferLen = *dataLen + offset;
    unsigned char * buffer = mallocSD(bufferLen);
    buffer[0] = 0;

    os_mem_cpy(buffer + offset, data, *dataLen);

    asn1_set_item(item, ASN_INTEGER, buffer, bufferLen, 0);

    // return the new length (if changed)
    *dataLen = bufferLen;

    return;
}


void asn1_lookup_property_oid(char * name, const char ** value) {

    const oid_t *p = oidTable;

    for (; p->name != NULL; ++p) {
        if (os_str_cmp(p->name, name) == 0) {
            *value = p->oid;
            return;
        }
    }
    *value = NULL;
    return;
}


void asn1_time_to_UTCTime(TIME_STR * time, unsigned char * outBuff) {

    os_str_snprintf(outBuff, 2, "%u", time->year % 100);
    os_str_snprintf(&outBuff[2], 2, "%02u", time->month);
    os_str_snprintf(&outBuff[4], 2, "%02u", time->day);
    os_str_snprintf(&outBuff[6], 2, "%02u", time->hour);
    os_str_snprintf(&outBuff[8], 2, "%02u", time->minute);
    os_str_snprintf(&outBuff[10], 2, "%02u", time->second);

    outBuff[12] = 'Z';
}


int asn1_set_bitstring_from_asn1(ASN1_ITEM * bitstring, ASN1_ITEM * content) {
    /* Sets the value of an ASN_BITSTRING with the encoded DER value of another
       ASN1_ITEM table. */

    unsigned char * buffer;
    size_t bufferLen = 0;
    int err;

    if ((err = asn1_encode_item(content, &buffer, &bufferLen)) != 0)
        return err;

    if ((err = asn1_set_bitstring(bitstring, buffer, bufferLen)) != 0)
        return err;

    return 0;
}


int asn1_set_bitstring(ASN1_ITEM * bitstring, unsigned char * buffer, size_t bufferLen) {

    unsigned char * bitdata;

    // append a zero to the front
    bitdata = mallocSD(bufferLen + 1);
    bitdata[0] = 0;

    if (NULL != buffer) {
        os_mem_cpy(bitdata + 1, buffer, bufferLen);
    }

    asn1_set_item(bitstring, ASN_BIT_STRING, bitdata, bufferLen + 1, 0);

    return 0;
}


void asn1_oid_str_to_bytes(char * oid /* zero-terminated */, unsigned char ** oidBytes, size_t * oidBytesLen) {

    unsigned char ** substrings = NULL;
    size_t count = 0;
    size_t i = 0;
    size_t j = 0;

    os_str_split(oid, os_str_len(oid), '.', &count, &substrings);

    // max size of output data
    size_t maxOut = count * sizeof(int);
    unsigned char * data = mallocSD(maxOut);
    j = maxOut - 1;

    int val;
    int cont = 0;

    for (i = count - 1; i > 1; i--) {
        val = atoi(substrings[i]);
        cont = 0;
        while (val > 128) {
            data[j--] = (val & 127) | cont;
            cont = 128;
            val = val >> 7;
        }
        data[j--] = val | cont;
    }

    val = atoi(substrings[0]);
    data[j] = val * 40;

    val = atoi(substrings[i]);
    data[j] += val;

    *oidBytes = mallocSD(maxOut - j);
    os_mem_cpy(*oidBytes, data + j, maxOut - j);
    *oidBytesLen = maxOut - j;

    return;
}


int asn1_find_by_path(asn1_table * table, const unsigned char * path, asn1_table * output) {

    unsigned int len = 0;
    int err = 0;

    while (path[++len]);

    // err if not found
    if ((err = asn1_find_item(table->table, (unsigned char *)path, &len, &output->table)) != 0)
        return err;

    output->length = asn1_get_child_count(output->table) + 1;

    return 0;
}


int asn1_get_sub_table_by_path(asn1_table * table, const unsigned char * path, asn1_table * subTable) {
    /* Returns a sub table from a parent table. The sub table will have it's own data buffer
    allowing the caller to free the parent buffer if they want. */
    int err;

    // find the sub-table
    if ((err = asn1_find_by_path(table, path, subTable)) != 0)
        return err;

    // set a new buffer
    asn1_copy_data_buffer(*subTable);

    return err;
}


void asn1_free_table(asn1_table table) {
    os_mem_del_set(table.table, 0);
}


void asn1_print_table(asn1_table * table) {

    asn1_fix_item_lengths(table->table);

    ASN1_ITEM * tableCopy = mallocSD(table->length * sizeof(ASN1_ITEM));

    os_mem_cpy(tableCopy, table->table, table->length * sizeof(ASN1_ITEM));

    int messageSize = asn1_get_item_total_len(tableCopy);

    unsigned char * message = mallocSD(messageSize);
    os_mem_set(message, 0, messageSize);

    // encode corrupts the table, we'll copy the table first
    int err = asn1_encode(tableCopy, table->length, 0, &message, &messageSize);

    os_mem_del_set(tableCopy, 0);

    unsigned int b64CertLen = (messageSize / 3) * 4 + 4;
    unsigned char * b64Cert = os_mem_new(b64CertLen, OS_MEM_TYPE_SD);
    os_mem_set(b64Cert, 0, b64CertLen);

    encodeToBase64(message, messageSize, b64Cert, &b64CertLen);
    b64Cert[b64CertLen] = 0;

    printHex("asn1_print_table : ", b64Cert, b64CertLen);

    return;
}


void asn1_copy_data_buffer(asn1_table table) {
    /* Each item in the table points to location in a larger buffer
       that contains the DER encoded bytes. We can get into situations where
       multiple tables point a single buffer. This would prevent freeing the
       buffer when we're done with a table. This function will create a new
       buffer just for this table */

    unsigned int bufferLen = asn1_get_item_total_len(table.table);
    unsigned char * newBuffer = os_mem_new(bufferLen, OS_MEM_TYPE_SD);
    unsigned int i;
    unsigned int offset;

    ASN1_ITEM lastChild = table.table[table.length - 1];
    unsigned int len = (lastChild.p_data + lastChild.len) - table.table->p_data;

    // copy all the data to the new buffer
    os_mem_cpy(newBuffer, table.table->p_data, len);

    // re-set table pointers to new buffer
    for (i = 0; i < table.length; i++)
    {
        offset = (table.table[i].p_data - table.table->p_data);
        table.table[i].p_data = newBuffer + offset;
    }

    return;
}
