/*! @file picnic_ext.h
 *  @brief Implementation of the Picnic module external API
 *
 *  This file is derived from the Picnic reference implementation
 *  (github.com/Microsoft/Picnic)
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


#ifndef __PICNIC_EXT_H
#define __PICNIC_EXT_H

#include <db.h>

// Global database var.  Use this to call database functions for this module.
extern MDL_GLOBAL DB *P_db;

// External function declarations. External functions are called from outside the HSM
extern int picnic_ext_sign(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_verify(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_keygen(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_keychk(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_keyimport(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_sign_decode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_sign_encode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_key_decode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);
extern int picnic_ext_key_encode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd);

#endif
