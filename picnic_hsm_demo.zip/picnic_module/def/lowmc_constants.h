/*! @file lowmc_constants.h
 *  @brief Constants needed to implement the LowMC block cipher.
 *
 *  This file is derived from the Picnic reference implementation
 *  (github.com/Microsoft/Picnic)
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */

#ifndef LOWMCCONSTANTS_H
#define LOWMCCONSTANTS_H

#include <stdint.h>
#include <stddef.h>
#include "picnic_impl.h"

#define WORD_SIZE_BITS 32 // the word size for the implementation. Not a LowMC parameter
#define LOWMC_MAX_STATE_SIZE 64

/* Return the LowMC linear matrix for this round */
const uint32_t* LMatrix(uint32_t round, paramset_t* params);

/* Return the LowMC key matrix for this round */
const uint32_t* KMatrix(uint32_t round, paramset_t* params);

/* Return the LowMC round constant for this round */
const uint32_t* RConstant(uint32_t round, paramset_t* params);

#endif /* LOWMCCONSTANTS_H */
