/*! @file picnic_ext.c
 *  @brief Implementation of the Picnic module external API
 *
 *  This file is derived from the Picnic reference implementation
 *  (github.com/Microsoft/Picnic)
 *
 *  The code is provided under the MIT license, see LICENSE for
 *  more details.
 *  SPDX-License-Identifier: MIT
 */


 /* Tells picnic.h that this is an internal module file - set before including picnic.h */
#define _PICNIC_C_INT_

#include <os_mem.h>
#include <os_log.h>
#include <adm.h>
#include "picnic_ext.h"
#include "picnic_int.h"
#include "picnic.h"


// picnic_init in picnic_global.c uses this to init the database
MDL_GLOBAL DB *P_db;

/*  Import a public and private key from bytes.
    The key data will be saved in the Picnic local DB using the supplied name.
    The sign and verify function will use this key name to lookup the key. */
int picnic_ext_keyimport(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd) {

    int           err = 0;
    unsigned char *p_answ = NULL;

    struct
    {
        unsigned int  l_key_name;   // key len
        unsigned char *p_key_name;  // key name
        unsigned int  l_pub;        // len pub key
        unsigned char *p_pub;       // pub key
        unsigned int  l_sec;        // len sec key
        unsigned char *p_sec;       // sec key
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "v2v2v2", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    // check the key
    if ((err = picnic_keychk(cmd.l_sec, cmd.p_sec, cmd.l_pub, cmd.p_pub)) != 0) {
        goto cleanup;
    }

    switch (err = db_insert(P_db, cmd.p_key_name, cmd.l_pub, cmd.p_pub, cmd.l_sec, cmd.p_sec))
    {
    case 0:
        break;

    case E_DB_EXISTS:
        if ((err = db_update(P_db, cmd.p_key_name, cmd.l_pub, cmd.p_pub, cmd.l_sec, cmd.p_sec)) != 0)
            goto cleanup;
        break;

    default:
        goto cleanup;
    }

    // allocate memory for answer data
    if ((err = cmds_alloc_answ(p_hdl, sizeof(unsigned int), &p_answ)) != 0)
        goto cleanup;

    memset(p_answ, 0, sizeof(unsigned int));

    return 0;

cleanup:

    return err;
}

/* Sign a message using the saved key pair */
int picnic_ext_sign(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{

    int           err = 0;
    unsigned char *p_answ = NULL;

    unsigned int lpk;
    unsigned int lsk;
    unsigned char * pk;
    unsigned char * sk;
    unsigned int lsig;
    unsigned char * sig = NULL;

    struct
    {
        unsigned int  l_key_name;   // key len
        unsigned char *p_key_name;  // name of key from keygen
        unsigned int  l_data;       // message to sign
        unsigned char *p_data;      // message len
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "v2v2", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    // get key from database
    if ((err = db_find(P_db, DB_EQUAL, cmd.p_key_name, &lpk, &pk, &lsk, &sk)) != 0)
        goto cleanup;

    if ((err = picnic_sign(lsk, sk, cmd.l_data, cmd.p_data, &lsig, &sig)) != 0)
        goto cleanup;

    // allocate memory for answer data
    if ((err = cmds_alloc_answ(p_hdl, lsig, &p_answ)) != 0)
        return(err);

    memcpy(p_answ, sig, lsig);

    return 0;

cleanup:

    return err;
}

/* Verify a signature using a previously signed message and a stored key */
int picnic_ext_verify(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{
    int           err = 0;
    unsigned char *p_answ = NULL;

    unsigned int lpk;
    unsigned int lsk;
    unsigned char * pk;
    unsigned char * sk;

    struct
    {
        unsigned int  l_key_name;   // key len
        unsigned char *p_key_name;  // name of key from keygen
        unsigned int  l_msg;        // message to sign
        unsigned char *p_msg;       // message len
        unsigned int  l_sig;        // signature
        unsigned char *p_sig;       // signature len
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "v2v2*", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    // get key from database
    if ((err = db_find(P_db, DB_EQUAL, cmd.p_key_name, &lpk, &pk, &lsk, &sk)) != 0)
        goto cleanup;

    if ((err = picnic_verify(lpk, pk, cmd.l_msg, cmd.p_msg, cmd.l_sig, cmd.p_sig)) != 0)
        goto cleanup;

    // allocate memory for answer data
    if ((err = cmds_alloc_answ(p_hdl, sizeof(unsigned int), &p_answ)) != 0)
        return(err);

    memset(p_answ, 0, sizeof(unsigned int));

    return 0;

cleanup:

    return err;
}

/* Generate a new key pair and store it in the local DB by name */
int picnic_ext_keygen(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{
    int           err = 0;
    unsigned char *p_answ = NULL;

    struct
    {
        unsigned int params;
        unsigned int l_key_name;
        unsigned char *key_name;
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "u2v2", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    unsigned int lpk;
    unsigned int lsk;

    unsigned char * pk;
    unsigned char * sk;

    picnic_keygen(cmd.params, &lsk, &sk, &lpk, &pk);

    // store key in database
    switch (err = db_insert(P_db, cmd.key_name, lpk, pk, lsk, sk))
    {
    case 0:
        break;

    case E_DB_EXISTS:
        if ((err = db_update(P_db, cmd.key_name, lpk, pk, lsk, sk)) != 0)
            goto cleanup;
        break;

    default:
        goto cleanup;
    }

    // allocate memory for answer data
    if ((err = cmds_alloc_answ(p_hdl, lpk, &p_answ)) != 0)
        return(err);

    memcpy(p_answ, pk, lpk);

    return 0;

cleanup:

    return err;
}

/* Verify that a serailized public & private key are valid */
int picnic_ext_keychk(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{
    int           err = 0;
    unsigned char *p_answ = NULL;

    struct
    {
        unsigned int  l_pub;        // len pub key
        unsigned char *p_pub;       // pub key
        unsigned int  l_sec;        // len sec key
        unsigned char *p_sec;       // sec key
    }
    cmd;

    // parse command data
    if ((err = cmds_scanf(l_cmd, p_cmd, "v2v2", sizeof(cmd), &cmd)) != 0)
        goto cleanup;

    // check the key
    if ((err = picnic_keychk(cmd.l_sec, cmd.p_sec, cmd.l_pub, cmd.p_pub)) != 0) {
        goto cleanup;
    }

    // allocate memory for answer data
    if ((err = cmds_alloc_answ(p_hdl, sizeof(unsigned int), &p_answ)) != 0)
        goto cleanup;

    memset(p_answ, 0, sizeof(unsigned int));

    return 0;

cleanup:

    return err;
}

/* Functions to encode/decoded keys and signature using ASN.1 
   These are currently unimplemented */
int picnic_ext_sign_decode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{   //(unsigned int l_sign, unsigned char* p_sign, unsigned int *p_l_s, unsigned char **pp_s) {

    return 0;
}


int picnic_ext_sign_encode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{   //(unsigned int l_s, unsigned char *p_s, unsigned int *p_l_sign, unsigned char *p_sign) {

    return 0;
}


int picnic_ext_key_decode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{   //(unsigned int l_key, unsigned char *p_key, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub, unsigned int *p_l_oid, unsigned char **pp_oid) {

    return 0;
}


int picnic_ext_key_encode(T_CMDS_HANDLE *p_hdl, int l_cmd, unsigned char *p_cmd)
{   //(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub, unsigned int l_oid, unsigned char *p_oid, unsigned int *p_l_key, unsigned char *p_key) {

    return 0;
}
