/*! @file picnic_pub.c
*  @brief Implementation of the Picnic module public API.
*  Modules call each other through the public APIs.
*
*  This file is derived from the Picnic reference implementation
*  (github.com/Microsoft/Picnic)
*
*  The code is provided under the MIT license, see LICENSE for
*  more details.
*  SPDX-License-Identifier: MIT
*/


/* Tells picnic.h that this is an internal module file - set before including picnic.h */
#define _PICNIC_C_INT_


#include <os_log.h>     /* HSM logging/print functions */
#include <os_mem.h>     /* HSM memory management functions */
#include "picnic_int.h"
#include "picnic.h"


int picnic_sign(unsigned int l_sec, unsigned char *p_sec, unsigned int l_m, unsigned char *p_m, unsigned int *p_l_sign, unsigned char **pp_sign) {

    picnic_privatekey_t sk;
    size_t signature_len;
    uint8_t* signature;
    int err = 0;

    if ((err = picnic_int_read_private_key(&sk, p_sec, l_sec)) != 0) {
        err = E_PICNIC_KDESERIALIZE_FAILED;
        goto cleanup;
    }

    signature_len = picnic_int_signature_size(sk.params);
    signature = malloc(signature_len);

    if ((err = picnic_int_sign(&sk, p_m, l_m, signature, &signature_len)) != 0) {
        err = E_PICNIC_SIGN_FAILED;
        goto cleanup;
    }

    *p_l_sign = signature_len;
    *pp_sign = signature;

    return 0;

cleanup:

    if (signature != NULL) os_mem_del(signature);
    *p_l_sign = 0;
    *pp_sign = NULL;

    return err;
}


int picnic_verify(unsigned int l_pub, unsigned char *p_pub, unsigned int l_m, unsigned char *p_m, unsigned int l_sign, unsigned char *p_sign) {

    picnic_publickey_t pk;

    int err = 0;

    if ((err = picnic_int_read_public_key(&pk, p_pub, l_pub)) != 0) {
        err = E_PICNIC_KDESERIALIZE_FAILED;
        goto cleanup;
    }

    // verify return -1 for both errors and failed verification
    err = picnic_int_verify(&pk, p_m, l_m, p_sign, l_sign);

cleanup:

    return err;
}


int picnic_keygen(unsigned int params, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub) {

    // Allocating memory for the returned keys. Caller must free.
    unsigned char * pkBytes = malloc(PICNIC_MAX_PUBLICKEY_SIZE);
    unsigned char * skBytes = malloc(PICNIC_MAX_PRIVATEKEY_SIZE);

    picnic_publickey_t pk;
    picnic_privatekey_t sk;

    int err = 0;

    if (pkBytes == NULL || skBytes == NULL) {
        err = E_PICNIC_MALLOC;
        goto cleanup;
    }

    // Generate a new key pair
    if ((err = picnic_int_keygen((picnic_params_t)params, &pk, &sk)) != 0) {
        err = E_PICNIC_KGEN_FAILED;
        goto cleanup;
    }

    // Serialize the keys to bytes (returns actual length of keys)
    *p_l_pub = picnic_int_write_public_key(&pk, pkBytes, PICNIC_MAX_PUBLICKEY_SIZE);
    *p_l_sec = picnic_int_write_private_key(&sk, skBytes, PICNIC_MAX_PRIVATEKEY_SIZE);

    if (*p_l_pub <= 0 || *p_l_sec <= 0) {
        err = E_PICNIC_KSERIALIZE_FAILED;
        goto cleanup;
    }

    // Return the serialized keys
    *pp_pub = pkBytes;
    *pp_sec = skBytes;

    return 0;

cleanup:

    if (pkBytes != NULL) os_mem_del(pkBytes);
    if (skBytes != NULL) os_mem_del(skBytes);

    *p_l_pub = 0;
    *p_l_sec = 0;
    *pp_pub = NULL;
    *pp_sec = NULL;

    return err;
}


int picnic_keychk(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub) {

    picnic_publickey_t pk;
    picnic_privatekey_t sk;

    int err = 0;

    if ((err = picnic_int_read_public_key(&pk, p_pub, l_pub)) != 0) {
        err = E_PICNIC_KDESERIALIZE_FAILED;
        goto cleanup;
    }

    if ((err = picnic_int_read_private_key(&sk, p_sec, l_sec)) != 0) {
        err = E_PICNIC_KDESERIALIZE_FAILED;
        goto cleanup;
    }

    err = picnic_int_validate_keypair(&sk, &pk);

cleanup:

    return err;
}


int picnic_sign_decode(unsigned int l_sign, unsigned char* p_sign, unsigned int *p_l_s, unsigned char **pp_s) {
    /* not implemented */
    return 0;
}


int picnic_sign_encode(unsigned int l_s, unsigned char *p_s, unsigned int *p_l_sign, unsigned char *p_sign) {
    /* not implemented */
    return 0;
}


int picnic_key_decode(unsigned int l_key, unsigned char *p_key, unsigned int *p_l_sec, unsigned char **pp_sec, unsigned int *p_l_pub, unsigned char **pp_pub, unsigned int *p_l_oid, unsigned char **pp_oid) {
    /* not implemented */
    return 0;
}


int picnic_key_encode(unsigned int l_sec, unsigned char *p_sec, unsigned int l_pub, unsigned char *p_pub, unsigned int l_oid, unsigned char *p_oid, unsigned int *p_l_key, unsigned char *p_key) {
    /* not implemented */
    return 0;
}
