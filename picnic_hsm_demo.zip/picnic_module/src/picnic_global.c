/*! @file picnic_global.c
*  @brief Picnic Module global file
*
*  This file is part of the Picnic signature HSM module.
*  This file contains structures and functions required
*  required by the HSM.
*
*  The code is provided under the MIT license, see LICENSE for
*  more details.
*  SPDX-License-Identifier: MIT
*/


/* Tells picnic.h that this is an internal module file - set before including picnic.h */
#define _PICNIC_C_INT_  


#include <module_1.5.h>
#include <os_log.h>
#include <adm.h>
#include "picnic.h"
#include "picnic_ext.h"


/* module id structure */
FILE_CONST T_MODULE_INFO Module_info =
{
  MODULE_INFO_TAG,
  PICNIC_MDL_NAME,
  CS2_U32_TO_BIG_ENDIAN(PICNIC_MDL_ID),
  CS2_U32_TO_BIG_ENDIAN(PICNIC_MDL_VERSION),
  PICNIC_MDL_NAMEX
};


/* public interface */
FILE_CONST T_PICNIC_TABLE_PUB Module_pub =
{
    /* required by HSM */
    NULL,
    picnic_start,
    picnic_stop,
    picnic_pre_replace,
    picnic_pre_delete,
    NULL,
    &Module_info,

    /* list of public functions our module will provide */
    picnic_sign,
    picnic_verify,
    picnic_keygen,
    picnic_keychk,
    picnic_sign_decode,
    picnic_sign_encode,
    picnic_key_decode,
    picnic_key_encode
};


/* references to other HSM modules */
#define MODULE_NEEDS_EXT_REFS
MDL_GLOBAL T_OS_MDL_HDL P_SMOS;
MDL_GLOBAL T_OS_MDL_HDL P_CMDS;
MDL_GLOBAL T_OS_MDL_HDL P_UTIL;
MDL_GLOBAL T_OS_MDL_HDL P_DB;
MDL_GLOBAL T_OS_MDL_HDL P_HASH;
MDL_GLOBAL T_OS_MDL_HDL P_ADM;

FILE_CONST T_MODULE_LINK_TAB Module_link_tab[] =
{
    /* handle      name.       version        flags   */
    {  &P_CMDS,    "CMDS",     0,             0  },
    {  &P_UTIL,    "UTIL",     0,             0  },
    {  &P_DB,      "DB",       0,             0  },
    {  &P_HASH,    "HASH",     0,             0  },
    {  &P_ADM,     "ADM",      0x03000600,    MODULE_OPTIONAL  },
    /*  marks end of table                      */
    {  NULL,       "",         0,             0  } 
};


/* picnic external interface - only required for testing */
#define MODULE_HAS_EXT_INTERFACE

FILE_CONST P_CMDS_FCT Module_func_tab[] =
{
    picnic_ext_sign,            // SFC = 0
    picnic_ext_verify,          // SFC = 1
    picnic_ext_keygen,          // SFC = 2
    picnic_ext_keychk,          // SFC = 3
    picnic_ext_keyimport,       // SFC = 4
    picnic_ext_sign_decode,     // SFC = 5
    picnic_ext_sign_encode,     // SFC = 6
    picnic_ext_key_decode,      // SFC = 7
    picnic_ext_key_encode       // SFC = 8
};


/* called when module starts */
int picnic_start(T_OS_MDL_HDL p_smos, OS_FILE_HANDLE p_spf, void *p_coff_mem)
{
    P_SMOS = p_smos;
    return module_start(p_coff_mem);
}


/* module_init_1.5.c uses these to initialize the module */
#define MODULE_INIT_TASK_STACK_SIZE    0x1000
#define MODULE_INIT_TASK_FUNCTION      picnic_init
#define MODULE_INIT_TASK_NAME          "INIT_PICNIC"


/* called to initialize module */
int picnic_init(void)
{
    int err;
    INIT_STAT DB_INFO db_info = { DB_INFO_TAG, 8, 0x100000 };

    /* open the internal picnic key database - creates if needed */
    P_db = NULL;
    if ((err = db_open("picnic", DB_CREAT, &db_info, &P_db)) != 0)
        return err;

    return(0);
}


int picnic_stop(void)
{
    return(0);
}


int picnic_pre_replace(void)
{
    return(0);
}


int picnic_pre_delete(void)
{
    return(0);
}


#undef _PICNIC_C_INT_

#include MODULE_INIT_C
